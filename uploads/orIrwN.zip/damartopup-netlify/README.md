# DamarTopup — Versi Netlify

Top up diamond multi-game dengan **auto-detect pembayaran** lewat Tripay
(QRIS/DANA/ShopeePay). Struktur ini dibuat khusus supaya jalan di Netlify:
frontend static + backend sebagai **Netlify Functions** (serverless).

## Struktur folder

```
damartopup-netlify/
├── public/                          → di-deploy sebagai root situs
│   ├── index.html
│   └── status.html
├── netlify/functions/
│   ├── firebase.js                  → helper koneksi Firestore (dipakai bareng)
│   ├── create-transaction.js        → bikin transaksi Tripay
│   ├── tripay-callback.js           → terima & verifikasi webhook Tripay
│   └── order-status.js              → dicek frontend via polling
├── netlify.toml                     → build config + redirect /api/* → functions
├── package.json
└── .env.example
```

## Kenapa strukturnya beda dari versi Node/Express biasa?

Netlify **tidak menjalankan server yang terus hidup** (seperti `app.listen()`
di Express). Yang dipakai adalah **Netlify Functions** — tiap file di
`netlify/functions/` jadi 1 endpoint serverless yang jalan cuma saat dipanggil.
`netlify.toml` mengatur supaya frontend tetap bisa memanggil path yang rapi
seperti `/api/create-transaction`, padahal di baliknya diarahkan ke
`/.netlify/functions/create-transaction`.

## Setup & Deploy

1. **Daftar Tripay** (sandbox dulu buat testing):
   https://tripay.co.id/ → catat Merchant Code, API Key, Private Key

2. **Setup Firebase Admin**:
   Firebase Console → project `xevo-1d7af` → Project Settings → Service Accounts
   → Generate new private key → download JSON

3. **Push folder ini ke GitHub repo baru** (Netlify deploy paling gampang lewat Git):
   ```bash
   cd damartopup-netlify
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <url-repo-kamu>
   git push -u origin main
   ```

4. **Di Netlify Dashboard**:
   - **Add new site → Import an existing project** → pilih repo tadi
   - Build settings biasanya otomatis kebaca dari `netlify.toml`:
     - Publish directory: `public`
     - Functions directory: `netlify/functions`
   - Klik **Deploy site**

5. **Set Environment Variables** di Netlify:
   Site settings → Environment variables → tambahkan satu-satu dari `.env.example`:
   - `TRIPAY_MODE`, `TRIPAY_API_KEY`, `TRIPAY_PRIVATE_KEY`, `TRIPAY_MERCHANT_CODE`
   - `APP_URL` — isi dengan URL Netlify kamu, misal `https://damartopup.netlify.app`
   - `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`

   Setelah menambahkan env vars, **trigger deploy ulang** (Deploys → Trigger deploy)
   supaya functions membaca env vars yang baru.

6. **Custom domain / subdomain Netlify** — kalau kamu masih pakai
   `crorceai.netlify.app` untuk project lain, buat **site baru** khusus untuk
   ini (misal `damartopup.netlify.app`) supaya tidak bentrok.

7. **Testing lokal (opsional, sebelum push)**:
   ```bash
   npm install -g netlify-cli
   cd damartopup-netlify
   npm install
   netlify dev
   ```
   Ini menjalankan frontend + functions sekaligus secara lokal, lengkap dengan
   env vars dari `.env` (buat file `.env` di root, isi sama seperti `.env.example`,
   `netlify dev` otomatis membacanya).

8. **Ganti ke mode production Tripay** kalau sudah siap jualan beneran:
   - Ajukan merchant Closed di dashboard Tripay (butuh KTP, verifikasi 1-3 hari)
   - Set `TRIPAY_MODE=production` di Environment Variables Netlify

## Alur kerja sistem

1. User pilih game, isi data, pilih metode bayar → klik "Bayar Sekarang"
2. Frontend panggil `POST /api/create-transaction` (diredirect ke function
   `create-transaction.js`) → bikin transaksi Tripay + simpan order
   `status: pending` ke Firestore collection `topup_orders`
3. User diarahkan ke halaman checkout Tripay (tab baru)
4. Setelah bayar, Tripay kirim webhook ke `POST /api/tripay-callback`
5. Function verifikasi signature webhook → update Firestore jadi `status: paid`
6. Frontend polling `GET /api/order-status/:merchantRef` tiap 4 detik →
   begitu `paid`, tampil sukses otomatis ke user — **tanpa upload bukti manual**

## Catatan penting

Pembayaran terdeteksi otomatis, tapi **pengiriman diamond ke akun game tetap
langkah terpisah** — manual olehmu, atau otomatis kalau nanti ada integrasi ke
API supplier diamond. Cek Firestore collection `topup_orders` dengan
`status: paid` untuk tahu order mana yang perlu diproses pengirimannya.

## Menambah game baru

Edit `public/index.html`, cari `const GAMES = [...]` dan
`const NOMINALS = {...}` — tambahkan entry baru sesuai game & harga yang mau dijual.

## Batasan Netlify Functions yang perlu diketahui

- **Timeout default 10 detik** per function call (cukup untuk semua endpoint di sini)
- **Cold start**: panggilan pertama setelah idle lama bisa sedikit lebih lambat
- Kalau traffic besar dan butuh function yang lebih cepat/lama, bisa upgrade ke
  Netlify Functions plan berbayar atau pindah sebagian ke Background Functions
