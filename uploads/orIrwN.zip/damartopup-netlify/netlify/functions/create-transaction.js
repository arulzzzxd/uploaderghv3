const axios = require("axios");
const crypto = require("crypto");
const { db, admin } = require("./firebase");

const TRIPAY_BASE_URL =
  process.env.TRIPAY_MODE === "production"
    ? "https://tripay.co.id/api"
    : "https://tripay.co.id/api-sandbox";

const PAYMENT_CHANNELS = {
  qris: "QRIS",
  dana: "DANA",
  shopeepay: "SHOPEEPAY",
};

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ success: false, message: "Method not allowed" }) };
  }

  try {
    const { game, gameId, item, price, userId, serverId, whatsapp, channel } = JSON.parse(event.body);

    if (!game || !item || !price || !userId || !whatsapp) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: "Data pesanan tidak lengkap" }),
      };
    }

    const method = PAYMENT_CHANNELS[channel] || "QRIS";
    const merchantRef = "DMR" + Date.now();

    const signature = crypto
      .createHmac("sha256", process.env.TRIPAY_PRIVATE_KEY)
      .update(process.env.TRIPAY_MERCHANT_CODE + merchantRef + price)
      .digest("hex");

    const appUrl = process.env.APP_URL || `https://${event.headers.host}`;

    const payload = {
      method,
      merchant_ref: merchantRef,
      amount: price,
      customer_name: whatsapp,
      customer_email: `${whatsapp}@damartopup.local`,
      customer_phone: whatsapp,
      order_items: [
        {
          sku: gameId || "item",
          name: `${game} - ${item}`,
          price,
          quantity: 1,
        },
      ],
      callback_url: `${appUrl}/.netlify/functions/tripay-callback`,
      return_url: `${appUrl}/status.html?ref=${merchantRef}`,
      expired_time: Math.floor(Date.now() / 1000) + 3600,
      signature,
    };

    const tripayRes = await axios.post(
      `${TRIPAY_BASE_URL}/transaction/create`,
      payload,
      { headers: { Authorization: `Bearer ${process.env.TRIPAY_API_KEY}` } }
    );

    const data = tripayRes.data.data;

    await db.collection("topup_orders").doc(merchantRef).set({
      game,
      gameId: gameId || null,
      item,
      price,
      userId,
      serverId: serverId || null,
      whatsapp,
      merchantRef,
      tripayReference: data.reference,
      paymentMethod: method,
      status: "pending",
      payUrl: data.checkout_url,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        merchantRef,
        checkoutUrl: data.checkout_url,
        qrUrl: data.qr_url || null,
        expiredAt: data.expired_time,
      }),
    };
  } catch (err) {
    console.error("create-transaction error:", err.response?.data || err.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: "Gagal membuat transaksi, coba lagi" }),
    };
  }
};
