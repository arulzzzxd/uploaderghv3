const crypto = require("crypto");
const { db, admin } = require("./firebase");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ success: false, message: "Method not allowed" }) };
  }

  try {
    // event.body dari Netlify adalah string mentah (belum di-parse) — ini yang
    // kita perlukan untuk verifikasi HMAC, karena signature dihitung dari
    // exact raw body, bukan hasil JSON.parse yang urutan key-nya bisa berubah.
    const rawBody = event.isBase64Encoded
      ? Buffer.from(event.body, "base64")
      : Buffer.from(event.body, "utf8");

    const signature = event.headers["x-callback-signature"] || event.headers["X-Callback-Signature"];

    const expectedSignature = crypto
      .createHmac("sha256", process.env.TRIPAY_PRIVATE_KEY)
      .update(rawBody)
      .digest("hex");

    if (signature !== expectedSignature) {
      console.warn("Tripay callback: signature tidak valid");
      return { statusCode: 403, body: JSON.stringify({ success: false, message: "Invalid signature" }) };
    }

    const payload = JSON.parse(rawBody.toString());
    const { merchant_ref, status } = payload;

    if (!merchant_ref) {
      return { statusCode: 400, body: JSON.stringify({ success: false, message: "merchant_ref hilang" }) };
    }

    const orderRef = db.collection("topup_orders").doc(merchant_ref);
    const orderSnap = await orderRef.get();

    if (!orderSnap.exists) {
      console.warn("Tripay callback: order tidak ditemukan", merchant_ref);
      return { statusCode: 404, body: JSON.stringify({ success: false, message: "Order tidak ditemukan" }) };
    }

    let newStatus = "pending";
    if (status === "PAID") newStatus = "paid";
    else if (status === "EXPIRED") newStatus = "expired";
    else if (status === "FAILED") newStatus = "failed";
    else if (status === "REFUND") newStatus = "refunded";

    await orderRef.update({
      status: newStatus,
      paidAt: newStatus === "paid" ? admin.firestore.FieldValue.serverTimestamp() : null,
      tripayRawStatus: status,
    });

    // Order otomatis "paid" di sini tanpa upload bukti manual. Pengiriman
    // diamond ke akun game tetap langkah terpisah (manual atau via supplier API).

    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } catch (err) {
    console.error("tripay-callback error:", err.message);
    return { statusCode: 500, body: JSON.stringify({ success: false }) };
  }
};
