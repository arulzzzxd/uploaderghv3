const { db } = require("./firebase");

exports.handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: JSON.stringify({ success: false, message: "Method not allowed" }) };
  }

  try {
    // Netlify Functions tidak punya routing path-param bawaan seperti Express,
    // jadi merchantRef dikirim lewat query string: /order-status?ref=DMR123
    const merchantRef = event.queryStringParameters?.ref;

    if (!merchantRef) {
      return { statusCode: 400, body: JSON.stringify({ success: false, message: "ref hilang" }) };
    }

    const snap = await db.collection("topup_orders").doc(merchantRef).get();

    if (!snap.exists) {
      return { statusCode: 404, body: JSON.stringify({ success: false, message: "Order tidak ditemukan" }) };
    }

    const data = snap.data();
    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        status: data.status,
        game: data.game,
        item: data.item,
        price: data.price,
      }),
    };
  } catch (err) {
    console.error("order-status error:", err.message);
    return { statusCode: 500, body: JSON.stringify({ success: false }) };
  }
};
